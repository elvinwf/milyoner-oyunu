const questions = [
    {
        question: "Azərbaycanın paytaxtı haradır?",
        answers: ["Gəncə", "Bakı", "Sumqayıt", "Şəki"],
        correct: 1
    },
    {
        question: "Xəzər dənizi hansı materikdə yerləşir?",
        answers: ["Afrika", "Avstraliya", "Avropa-Asiya", "Cənubi Amerika"],
        correct: 2
    },
    {
        question: "Azərbaycanın milli valyutası hansıdır?",
        answers: ["Dollar", "Lira", "Manat", "Rubl"],
        correct: 2
    },
    {
        question: "Nizami Gəncəvi hansı sahədə məşhurdur?",
        answers: ["Rəssamlıq", "Elm", "Musiqi", "Ədəbiyyat"],
        correct: 3
    }
];

let current = 0;

function loadQuestion() {
    const q = questions[current];
    document.getElementById('question').textContent = q.question;
    const answersDiv = document.getElementById('answers');
    answersDiv.innerHTML = "";
    q.answers.forEach((ans, i) => {
        const div = document.createElement("div");
        div.textContent = ans;
        div.className = "answer";
        div.onclick = () => checkAnswer(i, div);
        answersDiv.appendChild(div);
    });
}

function checkAnswer(selected, element) {
    const q = questions[current];
    const allAnswers = document.querySelectorAll(".answer");
    allAnswers.forEach(btn => btn.onclick = null); // Disable other buttons
    if (selected === q.correct) {
        element.classList.add("correct");
    } else {
        element.classList.add("wrong");
        allAnswers[q.correct].classList.add("correct");
    }
}

function nextQuestion() {
    current++;
    if (current < questions.length) {
        loadQuestion();
    } else {
        document.getElementById('question').textContent = "Təbriklər! Bütün sualları tamamladınız.";
        document.getElementById('answers').innerHTML = "";
        document.getElementById('next').style.display = "none";
    }
}

window.onload = loadQuestion;
